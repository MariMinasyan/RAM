package am.monopoly.exceptions;

/**
 * Thrown to indicate that a player has gone bankrupt in the Monopoly game.
 * This exception is used when a player cannot afford a required payment.
 */
public class BankruptcyException extends Exception {

    /**
     * Constructs a BankruptcyException with a default message.
     */
    public BankruptcyException() {
        super("You became bankrupt");
    }

    /**
     * Constructs a BankruptcyException with a custom message.
     *
     * @param msg the detail message explaining the cause of bankruptcy.
     */
    public BankruptcyException(String msg) {
        super(msg);
    }
}
