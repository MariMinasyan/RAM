package am.monopoly.exceptions;

/**
 * Thrown to indicate that a player does not have enough money to perform an action,
 * such as buying a property or paying rent in the Monopoly game.
 */
public class InsufficientAmountOfMoneyException extends Exception {

    /**
     * Constructs an InsufficientAmountOfMoneyException with a default message.
     */
    public InsufficientAmountOfMoneyException() {
        super("Insufficient amount of money");
    }

    /**
     * Constructs an InsufficientAmountOfMoneyException with a custom message.
     *
     * @param msg the detail message explaining the reason for the exception.
     */
    public InsufficientAmountOfMoneyException(String msg) {
        super(msg);
    }
}
