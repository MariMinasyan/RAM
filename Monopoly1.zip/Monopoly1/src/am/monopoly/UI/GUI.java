package am.monopoly.UI;

import am.monopoly.core.*;
import am.monopoly.exceptions.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The GUI class implements the graphical user interface for the Monopoly game.
 * It manages the game board layout, player interaction buttons, and player information panel.
 */
public class GUI {
    private JFrame frame;
    private JPanel boardPanel, centerPanel, controllerPanel, actionPanel;
    private JTextArea infoArea;
    private Game game;
    private JButton rollButton, buyButton, buildHouseButton, buildHotelButton, tradeButton, endTurnButton, endGameButton;

    /**
     * Displays the initial welcome screen with a "Start Game" button.
     */
    public void showStartWindow() {
        JFrame startFrame = new JFrame("Monopoly Game");
        startFrame.setSize(600, 400);
        startFrame.setLocationRelativeTo(null);
        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Monopoly Game", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        startFrame.add(titleLabel, BorderLayout.CENTER);

        JButton startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.BOLD, 18));
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startFrame.dispose();
                initialize();
            }
        });

        startFrame.add(startButton, BorderLayout.SOUTH);
        startFrame.setVisible(true);
    }

    /**
     * Initializes the main game window, including board, controls, and info display.
     */
    public void initialize() {
        game = new Game();
        frame = new JFrame("Monopoly Game");
        frame.setSize(1200, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        askForPlayers();

        boardPanel = new JPanel(new BorderLayout());
        controllerPanel = new JPanel(new FlowLayout());
        actionPanel = new JPanel(new FlowLayout());
        centerPanel = new JPanel(new BorderLayout());
        actionPanel.setVisible(true);

        JPanel top = new JPanel(new GridLayout(1, 10));
        JPanel bottom = new JPanel(new GridLayout(1, 10));
        JPanel left = new JPanel(new GridLayout(10, 1));
        JPanel right = new JPanel(new GridLayout(10, 1));

        for (int i = 0; i < 10; i++) {
            top.add(createSquareLabel(game.getBoard().getSquares().get(i)));
            bottom.add(createSquareLabel(game.getBoard().getSquares().get(19 - i)));
            left.add(createSquareLabel(game.getBoard().getSquares().get(20 + i)));
            right.add(createSquareLabel(game.getBoard().getSquares().get(39 - i)));
        }

        boardPanel.add(top, BorderLayout.NORTH);
        boardPanel.add(bottom, BorderLayout.SOUTH);
        boardPanel.add(left, BorderLayout.WEST);
        boardPanel.add(right, BorderLayout.EAST);
        boardPanel.add(centerPanel, BorderLayout.CENTER);

        setupButtons();

        infoArea = new JTextArea(10, 40);
        infoArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(infoArea);

        frame.add(boardPanel, BorderLayout.CENTER);
        frame.add(controllerPanel, BorderLayout.NORTH);
        frame.add(actionPanel, BorderLayout.SOUTH);
        frame.add(scrollPane, BorderLayout.EAST);

        refreshInfo();
        frame.setVisible(true);
    }

    /**
     * Creates and configures a label for a Monopoly board square.
     *
     * @param square the square to display.
     * @return a JLabel representing the square.
     */
    private JLabel createSquareLabel(Square square) {
        JLabel label = new JLabel("<html><center>" + square.getName() + "</center></html>", SwingConstants.CENTER);
        label.setOpaque(true);
        label.setBackground(getColorFromGroup(square.getColor()));
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        label.setFont(new Font("Arial", Font.PLAIN, 10));
        label.setPreferredSize(new Dimension(100, 60));
        return label;
    }

    /**
     * Prompts the user to enter the number of players and their names.
     */
    private void askForPlayers() {
        int count = Integer.parseInt(JOptionPane.showInputDialog("Enter number of players (2–4):"));
        while (count < 2 || count > 4) {
            count = Integer.parseInt(JOptionPane.showInputDialog("Invalid. Enter 2 to 4 players:"));
        }
        for (int i = 1; i <= count; i++) {
            String name = JOptionPane.showInputDialog("Enter name for Player " + i);
            game.addPlayer(name);
        }
    }

    /**
     * Rolls the dice and performs a turn for the current player.
     * Shows the result in a dialog and handles turn switching.
     */
    private void rollDice() {
        try {
            game.rollDice();
            String result = game.rollDiceAction();
            JOptionPane.showMessageDialog(frame, result);
            refreshInfo();

            if (!game.isLastRollDouble()) {
                game.nextTurn();
                refreshInfo();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, e.getMessage());
        }
    }

    /**
     * Attempts to buy the property the current player has landed on.
     */
    private void buyProperty() {
        try {
            Square s = game.getBoard().getSquare(game.getCurrentPlayer().getPosition());
            if (game.buy(s)) {
                JOptionPane.showMessageDialog(frame, "Bought " + s.getName());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, e.getMessage());
        }
        refreshInfo();
    }

    /**
     * Attempts to build a house on the current player's property.
     */
    private void buildHouse() {
        try {
            Square s = game.getBoard().getSquare(game.getCurrentPlayer().getPosition());
            if (game.buildHouse(s)) {
                JOptionPane.showMessageDialog(frame, "House built.");
            } else {
                JOptionPane.showMessageDialog(frame, "Cannot build house.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, e.getMessage());
        }
        refreshInfo();
    }

    /**
     * Attempts to build a hotel on the current player's property.
     */
    private void buildHotel() {
        try {
            Square s = game.getBoard().getSquare(game.getCurrentPlayer().getPosition());
            if (game.buildHotel(s)) {
                JOptionPane.showMessageDialog(frame, "Hotel built.");
            } else {
                JOptionPane.showMessageDialog(frame, "Cannot build hotel.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, e.getMessage());
        }
        refreshInfo();
    }

    /**
     * Placeholder for trading logic to be implemented in the future.
     */
    private void trade() {
        JOptionPane.showMessageDialog(frame, "Trading logic to be implemented.");
    }

    /**
     * Updates the info area to reflect the latest game state.
     */
    private void refreshInfo() {
        StringBuilder sb = new StringBuilder();
        for (Player p : game.getPlayers()) {
            sb.append("Player: ").append(p.getName())
                    .append(" | $").append(p.getMoney())
                    .append(" | Pos: ").append(game.getBoard().getSquare(p.getPosition()))
                    .append(" | Props: ");
            for (Property prop : p.getProperties()) {
                sb.append(prop.getName()).append(", ");
            }
            sb.append("\n");
        }
        sb.append("\n▶️ Current Turn: ").append(game.getCurrentPlayer().getName());
        infoArea.setText(sb.toString());
    }

    /**
     * Converts a property color group name into an actual Color object for display.
     *
     * @param colorGroup the name of the color group (e.g., "Red", "Blue").
     * @return the corresponding Color object.
     */
    private Color getColorFromGroup(String colorGroup) {
        switch (colorGroup) {
            case "Green": return new Color(0, 128, 0);
            case "Gray": return Color.LIGHT_GRAY;
            case "Blue": return new Color(70, 130, 180);
            case "Red": return Color.RED;
            case "Purple": return new Color(128, 0, 128);
            case "Pink": return new Color(255, 182, 193);
            case "Yellow": return Color.YELLOW;
            case "Teal": return new Color(0, 128, 128);
            case "Orange": return new Color(255, 165, 0);
            default: return Color.WHITE;
        }
    }

    /**
     * Sets up all control and action buttons and adds them to their respective panels.
     */
    private void setupButtons() {
        rollButton = new JButton("Roll Dice");
        rollButton.addActionListener(e -> rollDice());

        buyButton = new JButton("Buy Property");
        buyButton.addActionListener(e -> buyProperty());

        buildHouseButton = new JButton("Build House");
        buildHouseButton.addActionListener(e -> buildHouse());

        buildHotelButton = new JButton("Build Hotel");
        buildHotelButton.addActionListener(e -> buildHotel());

        tradeButton = new JButton("Trade");
        tradeButton.addActionListener(e -> trade());

        endTurnButton = new JButton("End Turn");
        endTurnButton.addActionListener(e -> {
            game.nextTurn();
            refreshInfo();
        });

        endGameButton = new JButton("End Game");
        endGameButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(frame, "Game Over! Winner: " + game.endTheGame());
            frame.dispose();
        });

        controllerPanel.add(rollButton);
        actionPanel.add(buyButton);
        actionPanel.add(buildHouseButton);
        actionPanel.add(buildHotelButton);
        actionPanel.add(tradeButton);
        actionPanel.add(endTurnButton);
        actionPanel.add(endGameButton);
    }
}
