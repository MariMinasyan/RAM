package am.monopoly;

import am.monopoly.UI.GUI;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            new GUI().showStartWindow();
        });
    }
}
