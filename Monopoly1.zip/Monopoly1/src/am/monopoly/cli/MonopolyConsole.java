package am.monopoly.cli;

import am.monopoly.core.*;
import am.monopoly.exceptions.BankruptcyException;
import am.monopoly.exceptions.InsufficientAmountOfMoneyException;

import java.util.*;

/**
 * The {@code MonopolyConsole} class represents the text-based version of the Monopoly game.
 * It handles user input, game flow, and interactions between players and the game logic.
 */
public class MonopolyConsole {
    /** Scanner for reading user input. */
    private final Scanner scanner = new Scanner(System.in);

    /** The core game logic instance. */
    private final Game game = new Game();

    /**
     * Starts the Monopoly game in console mode.
     * Manages player turns, actions, jail situations, and game progression.
     */
    public void run() {
        System.out.println("Welcome to Monopoly!");
        setupPlayers();

        while (!game.isGameOver()) {
            Player currentPlayer = game.getCurrentPlayer();
            System.out.println("\nIt's " + currentPlayer.getName() + "'s turn. ");

            if (currentPlayer.isInJail()) {
                System.out.println("You are in Jail!");
                System.out.println("What do you want to do? Here are options. Choose one: ");
                System.out.println("(1) Apply Get out of jail card");
                System.out.println("(2) Pay $50");
                System.out.println("(3) Roll dice");
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        if (currentPlayer.hasGetOutOfJailCard()) {
                            currentPlayer.applyGetOutOfJail();
                            System.out.println(currentPlayer.getName() + " applied Get out of jail card and is out of jail.");
                            break;
                        } else {
                            System.out.println("You don't have Get out of jail card");
                            game.nextTurn();
                            break;
                        }
                    case 2:
                        currentPlayer.receiveMoney(-50);
                        currentPlayer.outOfJail();
                        System.out.println(currentPlayer.getName() + " paid $50 and got out of jail ");
                        break;
                    case 3:
                        try {
                            String message = game.rollDiceAction();
                            game.nextTurn();
                            System.out.println(message);
                        } catch (Exception e) {}
                        break;
                }
            }

            System.out.println(currentPlayer.getName() + ", ready to roll dice? Type (y)es if ready: ");
            String ready = scanner.next();
            if (ready.equalsIgnoreCase("y") || ready.equalsIgnoreCase("yes")) {
                try {
                    String message = game.rollDiceAction();
                    if (message.contains("in jail")) {
                        game.nextTurn();
                    }
                    System.out.println(message);
                } catch (BankruptcyException | InsufficientAmountOfMoneyException e) {
                    System.out.println(e.getMessage());
                }
            }

            System.out.println("\nChoose an action:");
            System.out.println("(1). Buy");
            System.out.println("(2). Build House");
            System.out.println("(3). Build Hotel");
            System.out.println("(4). Sell Property");
            System.out.println("(5). Trade");
            System.out.println("(6). End the game");
            System.out.println("(7). End my turn");

            Square landedSquare = game.getBoard().getSquare(currentPlayer.getPosition());
            int action = scanner.nextInt();

            switch (action) {
                case 1:
                    try {
                        game.buy(landedSquare);
                    } catch (InsufficientAmountOfMoneyException e) {
                        System.out.println(e.getMessage());
                    }
                    System.out.println(currentPlayer.getName() + " have bought " + landedSquare.getName()
                            + "\nRemaining money is " + currentPlayer.getMoney());
                    break;
                case 2:
                    currentPlayer.want();
                    if (game.buildHouse(landedSquare)) {
                        System.out.println(currentPlayer.getName() + " has built a house on " + landedSquare.getName() + "."
                                + "\nRemaining money is " + currentPlayer.getMoney());
                    }
                    currentPlayer.doneWhatWanted();
                    break;
                case 3:
                    currentPlayer.want();
                    if (game.buildHotel(landedSquare)) {
                        System.out.println(currentPlayer.getName() + " has built a hotel on " + landedSquare.getName() + "."
                                + "\nRemaining money is " + currentPlayer.getMoney());
                    }
                    currentPlayer.doneWhatWanted();
                    break;
                case 4:
                    System.out.println("Enter property's name that you want to sell: ");
                    String propertyName = scanner.next();
                    Property p = game.getBoard().getPropertyByName(propertyName);
                    currentPlayer.removeProperty(p);
                    currentPlayer.receiveMoney(p.getPrice());
                    break;
                case 5:
                    handleTrade(currentPlayer);
                    break;
                case 6:
                    System.out.println("End of the Game. " + game.endTheGame() + " is the winner. Congratulations!");
                    return;
                case 7:
                    break;
            }

            if (game.isGameOver()) {
                System.out.println("Game over! Winner: " + game.endTheGame());
                break;
            }

            game.nextTurn();
        }
    }

    /**
     * Initializes the game by prompting the user for the number of players and their names.
     */
    private void setupPlayers() {
        System.out.print("Enter number of players (2-4): ");
        int count = getValidInt();
        for (int i = 1; i <= count; i++) {
            System.out.print("Enter name for Player " + i + ": ");
            String name = scanner.nextLine().trim();
            game.addPlayer(name);
        }
    }

    /**
     * Handles the trading process between two players.
     *
     * @param initiator the player who initiates the trade
     */
    private void handleTrade(Player initiator) {
        initiator.want();
        System.out.println("Enter your property's name that you want to offer: ");
        String property1Name = scanner.next();
        Property property1 = game.getBoard().getPropertyByName(property1Name);

        System.out.println("Enter your property's price that you want to trade: ");
        int property1Price = scanner.nextInt();

        System.out.println("Enter the player's name whose property you would like to trade: ");
        String playerName = scanner.next();
        Player tradingPlayer = game.getPlayerByName(playerName);

        System.out.println("What do you want in return? Enter property's name: ");
        String property2Name = scanner.next();
        Property property2 = game.getBoard().getPropertyByName(property2Name);

        System.out.println("Enter the player's property's price that you would like to trade: ");
        int property2Price = scanner.nextInt();

        System.out.println(tradingPlayer.getName() + " do you want to trade your property "
                + property2.getName() + " for a price of " + property2Price + " with "
                + initiator.getName() + "'s property " + property1.getName() + " with a price " + property1Price);
        System.out.println("Type (y)es if you want to trade: ");
        String trade2 = scanner.next();
        if (trade2.equalsIgnoreCase("y") || trade2.equalsIgnoreCase("yes")) tradingPlayer.want();

        if (game.trade(property1, property2, initiator, tradingPlayer, property1Price, property2Price)) {
            System.out.println(initiator.getName() + " has successfully traded his property "
                    + property1.getName() + " with " + tradingPlayer.getName() + "'s property " + property2.getName());
        }

        tradingPlayer.doneWhatWanted();
        initiator.doneWhatWanted();
    }

    /**
     * Prompts the user to enter a valid integer between 2 and 4.
     *
     * @return a valid player count
     */
    private int getValidInt() {
        while (true) {
            try {
                int value = Integer.parseInt(scanner.nextLine().trim());
                if (value >= 2 && value <= 4) return value;
            } catch (NumberFormatException ignored) {}
            System.out.print("Please enter a valid number (" + 2 + "-" + 4 + "): ");
        }
    }
}
