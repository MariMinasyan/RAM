package am.monopoly.utils;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * A utility class for handling file input operations used in the Monopoly game.
 */
public class FileIO {

    /**
     * Loads lines of text from a file at the specified path.
     *
     * @param path the path to the file.
     * @return an array of strings, each representing a line from the file.
     */
    public static String[] loadStringsFromFile(String path) {
        List<String> lines = new ArrayList<>();
        Scanner sc = null;

        try {
            sc = new Scanner(new FileInputStream(path));
            while (sc.hasNextLine()) {
                lines.add(sc.nextLine());
            }
        } catch (Exception e) {
            System.out.println("Error loading file: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (sc != null) {
                sc.close();
            }
        }
        return lines.toArray(new String[0]);
    }
}
