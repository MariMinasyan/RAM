package am.monopoly.core;

/**
 * Represents a square (tile) on the Monopoly board.
 * A square can be a property, utility, or a special action square.
 */
public class Square {

    /** The name of the square (e.g., "START", "INCOME TAX", "BERLIN"). */
    private String name;

    /** The position of the square on the board (0–39). */
    private int position;

    /** The color group associated with the square (used for properties or display). */
    private String color;

    /**
     * Constructs a Square with the given name, position, and color.
     *
     * @param name the name of the square.
     * @param position the position on the board.
     * @param color the color group or identifier.
     */
    public Square(String name, int position, String color) {
        this.name = name;
        this.position = position;
        this.color = color;
    }

    /**
     * Returns the name of the square.
     *
     * @return the name.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the position of the square on the board.
     *
     * @return the position index (0–39).
     */
    public int getPosition() {
        return position;
    }

    /**
     * Returns the color group or identifier of the square.
     *
     * @return the color string.
     */
    public String getColor() {
        return color;
    }
}
