package am.monopoly.core;

import am.monopoly.exceptions.BankruptcyException;
import am.monopoly.exceptions.InsufficientAmountOfMoneyException;

import java.util.ArrayList;

/**
 * Manages the overall logic of a Monopoly game, including players, turns, dice rolls,
 * movement, property actions, and win conditions.
 */
public class Game {

    /** List of players in the game. */
    private ArrayList<Player> players;

    /** The game board instance. */
    private Board board;

    /** Index of the current player. */
    private int currentPlayerIndex;

    /** Array holding the results of two dice. */
    private int[] dice = new int[2];

    /** Number of houses available in the bank. */
    private int numberOfHouses, numberOfHotels;

    /**
     * Constructs a new Game with initialized board, players list, and available buildings.
     */
    public Game() {
        players = new ArrayList<>();
        board = new Board();
        currentPlayerIndex = 0;
        numberOfHouses = 32;
        numberOfHotels = 12;
    }

    /**
     * Adds a new player to the game with the given name.
     *
     * @param nameOfPlayer the player's name.
     */
    public void addPlayer(String nameOfPlayer) {
        Player newPlayer = new Player(nameOfPlayer, 1500);
        players.add(newPlayer);
    }

    /**
     * Returns the current player whose turn it is.
     *
     * @return the current Player.
     */
    public Player getCurrentPlayer() {
        return players.get(currentPlayerIndex);
    }

    /**
     * Rolls the two dice and stores their values.
     */
    public void rollDice() {
        dice[0] = (int) (Math.random() * 6) + 1;
        dice[1] = (int) (Math.random() * 6) + 1;
    }

    /**
     * Checks whether the last dice roll was a double.
     *
     * @return true if both dice have the same value; false otherwise.
     */
    public boolean lastRollWasDouble() {
        return dice[0] == dice[1];
    }

    /**
     * Executes the dice roll action for the current player, including handling jail,
     * doubles, and movement.
     *
     * @return result message after the action.
     * @throws BankruptcyException if the player goes bankrupt.
     * @throws InsufficientAmountOfMoneyException if a player can't pay rent or purchase.
     */
    public String rollDiceAction() throws BankruptcyException, InsufficientAmountOfMoneyException {
        rollDice();
        int firstDie = dice[0];
        int secondDie = dice[1];
        int sum = firstDie + secondDie;

        if (getCurrentPlayer().isInJail()) {
            if (firstDie == secondDie) {
                getCurrentPlayer().outOfJail();
                nextTurn();
                return getCurrentPlayer().getName() + " rolled " + firstDie + " " + secondDie + " and is out of jail now";
            } else {
                return getCurrentPlayer().getName() + " rolled " + firstDie + " " + secondDie + " and is still in jail";
            }
        }

        if (firstDie == secondDie) {
            rollDice(); // second roll
            int secondFirstDie = dice[0];
            int secondSecondDie = dice[1];

            if (secondFirstDie == secondSecondDie) {
                if (getCurrentPlayer().hasGetOutOfJailCard()) {
                    getCurrentPlayer().applyGetOutOfJail();
                    return getCurrentPlayer().getName() + " applied get out of jail card";
                }
                getCurrentPlayer().goToJail();
                nextTurn();
                return getCurrentPlayer().getName() + " rolled two doubles and is in jail.";
            }

            sum += secondFirstDie + secondSecondDie;
            return movePlayer(sum) + getCurrentPlayer().getName() + " rolled " + sum + " and moved to "
                    + board.getSquare(getCurrentPlayer().getPosition()).getName()
                    + "\nRemaining money is " + getCurrentPlayer().getMoney();
        }

        return movePlayer(sum) + " " + getCurrentPlayer().getName() + " rolled " + sum
                + " and moved to " + board.getSquare(getCurrentPlayer().getPosition()).getName()
                + "\nRemaining money is " + getCurrentPlayer().getMoney();
    }

    /**
     * Moves the current player by the given roll value and handles square effects.
     *
     * @param roll number of steps to move.
     * @return message about the outcome.
     * @throws BankruptcyException if the player can't pay rent.
     * @throws InsufficientAmountOfMoneyException if payment is impossible.
     */
    public String movePlayer(int roll) throws BankruptcyException, InsufficientAmountOfMoneyException {
        Player currentPlayer = getCurrentPlayer();
        currentPlayer.move(roll);
        if (currentPlayer.getPosition() != 11) {
            return landOnSquare();
        }
        currentPlayer.goToJail();
        String currentPlayerName = currentPlayer.getName();
        nextTurn();
        return currentPlayerName + " went to jail.";
    }

    /**
     * Switches to the next player's turn.
     */
    public void nextTurn() {
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
    }

    /**
     * Allows the current player to buy a property or utility if eligible.
     *
     * @param square the square to be bought.
     * @return true if the purchase was successful; false otherwise.
     * @throws InsufficientAmountOfMoneyException if the player cannot afford the cost.
     */
    public boolean buy(Square square) throws InsufficientAmountOfMoneyException {
        if (square instanceof Property property) {
            for (Player player : players) {
                if (player.getProperties().contains(property)) return false;
            }
            if (getCurrentPlayer().getMoney() >= property.getPrice()) {
                getCurrentPlayer().receiveMoney(-property.getPrice());
                getCurrentPlayer().addProperty(property);
                return true;
            } else {
                throw new InsufficientAmountOfMoneyException();
            }
        } else if (square instanceof Utility utility) {
            for (Player player : players) {
                if (player.getUtilities().contains(utility)) return false;
            }
            if (getCurrentPlayer().getMoney() >= utility.getPrice()) {
                getCurrentPlayer().receiveMoney(-utility.getPrice());
                getCurrentPlayer().addUtility(utility);
                return true;
            } else {
                throw new InsufficientAmountOfMoneyException();
            }
        } else {
            throw new IllegalArgumentException("Can't buy");
        }
    }

    /**
     * Handles property trading between two players if conditions are met.
     *
     * @return true if trade is successful; false otherwise.
     */
    public boolean trade(Property p1, Property p2, Player trader, Player player, int price1, int price2) {
        if (getCurrentPlayer() != trader || getCurrentPlayer() == player) return false;
        if (!trader.getProperties().contains(p1) || !player.getProperties().contains(p2)) return false;

        if (player.ifWants() && trader.hasEnoughMoney(price2) && player.hasEnoughMoney(price1)) {
            executeTrade(p1, p2, trader, player, price1, price2);
            return true;
        }
        return false;
    }

    /**
     * Executes a trade between two players by exchanging properties and money.
     */
    private void executeTrade(Property p1, Property p2, Player trader, Player player, int price1, int price2) {
        trader.receiveMoney(-price2);
        player.receiveMoney(price2);
        player.receiveMoney(-price1);
        trader.receiveMoney(price1);

        trader.removeProperty(p1);
        player.addProperty(p1);
        player.removeProperty(p2);
        trader.addProperty(p2);
    }

    /**
     * Checks if the current player can build a house on the specified property.
     */
    public boolean canBuildHouse(Property property) {
        return hasMonopoly(property)
                && numberOfHouses >= 1
                && property.getStatus() == Property.Status.HOUSE
                && property.getNumberOfStatus() < 4;
    }

    /**
     * Checks if the current player can build a hotel on the specified property.
     */
    public boolean canBuildHotel(Property property) {
        return hasMonopoly(property)
                && numberOfHotels >= 1
                && property.getNumberOfStatus() == 4;
    }

    /**
     * Checks if the current player has a monopoly over all properties of the same color.
     */
    private boolean hasMonopoly(Property property) {
        return getCurrentPlayer().getProperties().containsAll(board.getPropertiesByColor(property.getColor()));
    }

    /**
     * Handles landing on a square, applying rent, taxes, or drawing cards as needed.
     */
    public String landOnSquare() throws BankruptcyException, InsufficientAmountOfMoneyException {
        Player currentPlayer = getCurrentPlayer();
        Square square = board.getSquare(currentPlayer.getPosition());
        String message = "";

        if ((currentPlayer.getPreviousPosition() > currentPlayer.getPosition()) && currentPlayer.getPosition() != 0) {
            currentPlayer.receiveMoney(200);
            message = currentPlayer.getName() + " received $200.";
        }

        if (square instanceof Property property) {
            for (Player player : players) {
                if (player != currentPlayer && player.getProperties().contains(property)) {
                    currentPlayer.payRent(property, player);
                    return currentPlayer.getName() + " pays rent for " + property.getName() + " to " + player.getName() + "\n" + message;
                }
            }
        } else if (square instanceof Utility utility) {
            for (Player player : players) {
                if (player != currentPlayer && player.getUtilities().contains(utility)) {
                    currentPlayer.payRent(utility, player);
                    return currentPlayer.getName() + " pays rent for " + utility.getName() + " to " + player.getName() + "\n" + message;
                }
            }
        } else {
            switch (square.getName()) {
                case "START":
                    currentPlayer.receiveMoney(300);
                    return currentPlayer.getName() + " receives $300." + "\n" + message;
                case "GO TO JAIL":
                    currentPlayer.goToJail();
                    return currentPlayer.getName() + " goes to jail." + "\n" + message;
                case "INCOME TAX":
                    currentPlayer.receiveMoney(-100);
                    return currentPlayer.getName() + " paid $100 tax." + "\n" + message;
                case "FREE PARKING":
                    nextTurn();
                    break;
                case "CHANCE CARD":
                case "COMMUNITY CHEST":
                    ChanceCard card = board.takeChanceCard();
                    String m = card.applyEffect(currentPlayer);
                    nextTurn();
                    return currentPlayer.getName() + " drew a chance card: " + card + ". " + m + "\n" + message;
                case "IN JAIL":
                    return currentPlayer.getName() + " is in jail." + "\n" + message;
            }
        }

        return "";
    }

    /**
     * Attempts to build a house on the given square.
     */
    public boolean buildHouse(Square square) {
        if (!(square instanceof Property property)) throw new IllegalArgumentException("Not a property.");
        if (canBuildHouse(property)) {
            constructHouse(property);
            return true;
        }
        return false;
    }

    /**
     * Attempts to build a hotel on the given square.
     */
    public boolean buildHotel(Square square) {
        if (!(square instanceof Property property)) throw new IllegalArgumentException("Not a property.");
        if (canBuildHotel(property)) {
            constructHotel(property);
            return true;
        }
        return false;
    }

    /**
     * Constructs a house on the given property and updates house count.
     */
    private void constructHouse(Property property) {
        property.buildHouse();
        numberOfHouses--;
    }

    /**
     * Constructs a hotel on the given property and updates hotel and house count.
     */
    private void constructHotel(Property property) {
        numberOfHouses += 4;
        property.setNumberOfStatus(0);
        property.setStatus(Property.Status.HOTEL);
        numberOfHotels--;
    }

    /**
     * Removes a player from the game and clears their properties.
     */
    public void exitFromTheGame(Player player) {
        player.getProperties().clear();
        player.getUtilities().clear();
        players.remove(player);
    }

    /**
     * Checks whether the game has ended (only one player left).
     */
    public boolean isGameOver() {
        return players.size() == 1;
    }

    /**
     * Returns the winner based on the highest amount of money.
     */
    public String endTheGame() {
        int max = 0;
        Player winner = null;
        for (Player p : players) {
            if (p.getMoney() > max) {
                max = p.getMoney();
                winner = p;
            }
        }
        return winner != null ? winner.getName() : "No winner";
    }

    /**
     * Gets the first player in the list as the current winner.
     */
    public String getWinner() {
        return players.getFirst().getName();
    }

    /**
     * Returns the game board.
     */
    public Board getBoard() {
        return board;
    }

    /**
     * Returns an array of all players.
     */
    public Player[] getPlayers() {
        return players.toArray(new Player[0]);
    }

    /**
     * Retrieves a player by their name.
     */
    public Player getPlayerByName(String nameOfPlayer) {
        for (Player player : players) {
            if (player.getName().equals(nameOfPlayer)) {
                return player;
            }
        }
        return null;
    }

    /**
     * Checks whether the last dice roll was a double.
     */
    public boolean isLastRollDouble() {
        return dice[0] == dice[1];
    }
}
