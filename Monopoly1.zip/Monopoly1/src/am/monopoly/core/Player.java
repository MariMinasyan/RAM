package am.monopoly.core;

import am.monopoly.exceptions.BankruptcyException;
import am.monopoly.exceptions.InsufficientAmountOfMoneyException;

import java.util.ArrayList;

/**
 * Represents a player in the Monopoly game. Each player has a name, money, position,
 * owned properties and utilities, and jail status.
 */
public class Player {

    /** The player's name. */
    private String name;

    /** The amount of money the player currently has. */
    private int money;

    /** The current position of the player on the board. */
    private int position;

    /** The player's position before their most recent move. */
    private int previousPosition;

    /** Indicates whether the player is currently in jail. */
    private boolean inJail;

    /** Stores "Get Out of Jail Free" cards the player may own. */
    private ChanceCard getOut1, getOut2;

    /** Properties owned by the player. */
    private ArrayList<Property> properties;

    /** Utilities owned by the player. */
    private ArrayList<Utility> utilities;

    /** Tracks if the player wants to participate in an action like trading. */
    private boolean wants;

    /**
     * Constructs a Player with the specified name and starting money.
     *
     * @param name the player's name.
     * @param startingMoney the starting amount of money.
     */
    public Player(String name, int startingMoney) {
        this.name = name;
        this.money = startingMoney;
        this.position = 0;
        this.inJail = false;
        this.properties = new ArrayList<>();
        this.utilities = new ArrayList<>();
    }

    /**
     * Returns the player's name.
     *
     * @return the name.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the amount of money the player has.
     *
     * @return the money.
     */
    public int getMoney() {
        return money;
    }

    /**
     * Returns the player's current board position.
     *
     * @return the position index.
     */
    public int getPosition() {
        return position;
    }

    /**
     * Returns the player's previous board position before the last move.
     *
     * @return the previous position.
     */
    public int getPreviousPosition() {
        return previousPosition;
    }

    /**
     * Moves the player forward by a specified number of steps.
     *
     * @param roll the number to move forward.
     */
    public void move(int roll) {
        previousPosition = position;
        position = (position + roll) % 40;
    }

    /**
     * Sends the player to jail (position 11) and sets jail status to true.
     */
    public void goToJail() {
        inJail = true;
        position = 11;
    }

    /**
     * Frees the player from jail.
     */
    public void outOfJail() {
        inJail = false;
    }

    /**
     * Returns whether the player is currently in jail.
     *
     * @return true if in jail; false otherwise.
     */
    public boolean isInJail() {
        return inJail;
    }

    /**
     * Adds or subtracts money from the player's total.
     *
     * @param amount the amount to adjust by (can be negative).
     */
    public void receiveMoney(int amount) {
        money += amount;
    }

    /**
     * Pays rent to another player based on the square landed on.
     *
     * @param square the square requiring rent.
     * @param receiver the player receiving the rent.
     * @throws BankruptcyException if the payer lacks sufficient funds.
     */
    public void payRent(Square square, Player receiver) throws BankruptcyException {
        int rentAmount = 0;
        if (square instanceof Property property) {
            rentAmount = property.calculateRent();
        } else if (square instanceof Utility utility) {
            rentAmount = utility.getRent();
        }

        if (money >= rentAmount) {
            money -= rentAmount;
            receiver.receiveMoney(rentAmount);
        } else {
            throw new BankruptcyException();
        }
    }

    /**
     * Returns a list of properties the player owns.
     *
     * @return list of properties.
     */
    public ArrayList<Property> getProperties() {
        return properties;
    }

    /**
     * Returns a list of utilities the player owns.
     *
     * @return list of utilities.
     */
    public ArrayList<Utility> getUtilities() {
        return utilities;
    }

    /**
     * Adds a property to the player's ownership.
     *
     * @param property the property to add.
     */
    protected void addProperty(Property property) {
        properties.add(property);
    }

    /**
     * Removes a property from the player's ownership.
     *
     * @param property the property to remove.
     */
    public void removeProperty(Property property) {
        properties.remove(property);
    }

    /**
     * Adds a utility to the player's ownership.
     *
     * @param utility the utility to add.
     */
    protected void addUtility(Utility utility) {
        utilities.add(utility);
    }

    /**
     * Removes a utility from the player's ownership.
     *
     * @param utility the utility to remove.
     */
    public void removeUtility(Utility utility) {
        utilities.remove(utility);
    }

    /**
     * Checks whether the player has enough money for a specific amount.
     *
     * @param amount the required amount.
     * @return true if the player has enough; false otherwise.
     */
    public boolean hasEnoughMoney(int amount) {
        return money >= amount;
    }

    /**
     * Adds a "Get Out of Jail Free" card to the player.
     *
     * @param chanceCard the chance card to store.
     */
    public void receiveGetOutOfJail(ChanceCard chanceCard) {
        if (getOut1 != null)
            this.getOut2 = chanceCard;
        else
            this.getOut1 = chanceCard;
    }

    /**
     * Checks whether the player has any "Get Out of Jail Free" card.
     *
     * @return true if player has at least one; false otherwise.
     */
    public boolean hasGetOutOfJailCard() {
        return getOut1 != null || getOut2 != null;
    }

    /**
     * Uses a "Get Out of Jail Free" card and frees the player from jail.
     */
    public void applyGetOutOfJail() {
        outOfJail();
        if (getOut1 != null) {
            getOut1 = null;
            return;
        }
        if (getOut2 != null) {
            getOut2 = null;
        }
    }

    /**
     * Constructs a house on a property if the player owns it and it's eligible.
     *
     * @param property the property to build on.
     */
    public void buildHouse(Property property) {
        if (properties.contains(property) && property.getStatus() != Property.Status.HOTEL) {
            if (property.getNumberOfStatus() <= 4) {
                property.setNumberOfStatus(property.getNumberOfStatus() + 1);
                property.setRent(property.getRent() * 2);
                property.setStatus(Property.Status.HOUSE);
            }
        }
    }

    /**
     * Constructs a hotel on a property if it's fully upgraded with houses.
     *
     * @param property the property to upgrade.
     */
    public void buildHotel(Property property) {
        if (properties.contains(property) && property.getStatus() == Property.Status.HOUSE
                && property.getNumberOfStatus() == 4) {
            property.setStatus(Property.Status.HOTEL);
            property.setNumberOfStatus(1);
            property.setRent(property.getRent() * 2);
        }
    }

    /**
     * Indicates that the player is willing to trade or take an action.
     */
    public void want() {
        wants = true;
    }

    /**
     * Indicates the player is no longer participating in a temporary action like trade.
     */
    public void doneWhatWanted() {
        wants = false;
    }

    /**
     * Checks whether the player is currently in a "wants" state.
     *
     * @return true if the player is marked as wanting to act.
     */
    public boolean ifWants() {
        return wants;
    }

    /**
     * Adjusts the player's money based on a win or loss from mini-game events.
     *
     * @param b whether the player won (true) or lost (false).
     * @param numbersOfDice the dice value affecting reward/penalty.
     */
    public void winOrLose(boolean b, int numbersOfDice) {
        if (b) {
            money += (numbersOfDice * 5);
        } else {
            money -= (numbersOfDice * 5);
        }
    }
}
