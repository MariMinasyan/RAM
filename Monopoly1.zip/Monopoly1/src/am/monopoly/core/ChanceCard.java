package am.monopoly.core;

import am.monopoly.exceptions.BankruptcyException;

/**
 * Represents a chance card in the Monopoly game, each of which has a specific type and optional effect.
 * Chance cards can apply various effects to a player when drawn.
 */
public class ChanceCard {

    /** The type of the chance card (e.g., MOVE, PAY, GO_TO_JAIL, etc.). */
    private Cards type;

    /** The amount associated with the card effect, used in MOVE or monetary actions. */
    private int amount;

    /**
     * Enum representing all possible types of chance cards.
     */
    public enum Cards {
        MOVE,
        PAY,
        GO_TO_JAIL,
        ADVANCE_TO_GO,
        BANK_COLLECT,
        DOCTORS_FEE,
        YOU_INHERIT,
        PAY_HOSPITAL_FEES,
        GET_OUT_OF_JAIL
    }

    /**
     * Constructs a ChanceCard with the specified type.
     * A random amount between 1 and 3 (inclusive) is assigned for applicable effects.
     *
     * @param type the type of the chance card.
     */
    public ChanceCard(Cards type) {
        this.type = type;
        this.amount = (int) (Math.random() * 3 + 1);
    }

    /**
     * Returns the type of this chance card.
     *
     * @return the card type.
     */
    public Cards getType() {
        return type;
    }

    /**
     * Returns a string representation of the card's type.
     *
     * @return the type as a string.
     */
    public String toString() {
        return type.toString();
    }

    /**
     * Applies the effect of the chance card to the specified player.
     *
     * @param p the player to whom the effect is applied.
     * @return a message describing the effect applied.
     * @throws BankruptcyException if the player cannot afford a payment.
     * @throws NullPointerException if the player is null.
     */
    public String applyEffect(Player p) throws BankruptcyException {
        if (p == null) {
            throw new NullPointerException("The player is null");
        }
        switch (type) {
            case MOVE:
                p.move(amount);
                return p.getName() + " moved " + amount;
            case PAY:
                p.receiveMoney(-150);
                return p.getName() + " payed " + amount;
            case GO_TO_JAIL:
                p.goToJail();
                return p.getName() + " went to Jail ";
            case ADVANCE_TO_GO:
                p.move(0);
                return p.getName() + " went to GO ";
            case BANK_COLLECT:
                p.receiveMoney(100);
                return p.getName() + " collected " + amount;
            case DOCTORS_FEE:
                p.receiveMoney(-50);
                return p.getName() + " paid $50 for Doctors Fees ";
            case YOU_INHERIT:
                p.receiveMoney(200);
                return " " + p.getName() + " inherited $200 ";
            case PAY_HOSPITAL_FEES:
                p.receiveMoney(-25);
                return p.getName() + " paid $25 for Hospital Fees ";
            case GET_OUT_OF_JAIL:
                p.receiveGetOutOfJail(this);
                return p.getName() + " received get out of jail ";
        }
        return "";
    }
}
