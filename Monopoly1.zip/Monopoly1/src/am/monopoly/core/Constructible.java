package am.monopoly.core;

import am.monopoly.core.Property.Status;

/**
 * Represents an interface for objects that can be constructed upon in the Monopoly game,
 * such as properties where houses and hotels can be built.
 */
public interface Constructible {

    /**
     * Builds a house on the constructible entity.
     * Typically, increases the property's development level.
     */
    void buildHouse();

    /**
     * Sets the status of the constructible entity (e.g., NONE, HOUSE, HOTEL).
     *
     * @param status the new status to be set.
     */
    void setStatus(Status status);

    /**
     * Gets the current status of the constructible entity.
     *
     * @return the current status.
     */
    Status getStatus();

    /**
     * Sets the number of current constructions (houses/hotels) on the entity.
     *
     * @param numberOfStatus the number of constructions.
     */
    void setNumberOfStatus(int numberOfStatus);

    /**
     * Gets the number of constructions (houses/hotels) on the entity.
     *
     * @return the number of constructions.
     */
    int getNumberOfStatus();
}
