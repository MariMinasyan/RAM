package am.monopoly.core;

import am.monopoly.utils.FileIO;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Represents the game board for Monopoly, including all squares and chance cards.
 * It initializes the board from a data file and handles property and chance card logic.
 */
public class Board {

    /** The list of all squares (properties, utilities, and special squares) on the board. */
    private final ArrayList<Square> squares;

    /** Constant indicating the total number of squares on the board. */
    public final int NUMBER_OF_SQUARES = 40;

    /** The list of chance cards used in the game. */
    private ArrayList<ChanceCard> cards;

    /** File path to the board data configuration. */
    private String path = "C:\\Users\\Raffi\\Desktop\\Data.txt";

    /** Constant indicating the total number of chance cards to be initialized. */
    public final int NUMBER_OF_CARDS = 28;

    /**
     * Returns the list of all squares on the board.
     *
     * @return an ArrayList of Square objects.
     */
    public ArrayList<Square> getSquares() {
        return squares;
    }

    /**
     * Retrieves a property by its name.
     *
     * @param propertyName the name of the property to search for.
     * @return the Property object if found; otherwise, null.
     */
    public Property getPropertyByName(String propertyName) {
        for (Square square : squares) {
            if (square.getName().equalsIgnoreCase(propertyName)) {
                if (square instanceof Property) {
                    return (Property) square;
                }
            }
        }
        return null;
    }

    /**
     * Retrieves all properties that have the specified color group.
     *
     * @param color the color group to filter by.
     * @return an ArrayList of Property objects matching the color.
     */
    public ArrayList<Property> getPropertiesByColor(String color) {
        ArrayList<Property> properties = new ArrayList<>();
        for (Square square : squares) {
            if (square.getColor().equals(color)) {
                properties.add((Property) square);
            }
        }
        return properties;
    }

    /**
     * Constructs the Board by reading square data from a file and initializing chance cards.
     */
    public Board() {
        squares = new ArrayList<>();
        String[] data = FileIO.loadStringsFromFile(path);

        for (int i = 0; i < NUMBER_OF_SQUARES; i++) {
            String[] s = data[i].split(",");
            switch (s[0].charAt(0)) {
                case '$':
                    squares.add(new Property(s[0].substring(1), i, Integer.parseInt(s[1]),
                            Integer.parseInt(s[2]), s[3]));
                    break;
                case '#':
                    squares.add(new Square(s[0].substring(1), i, s[1]));
                    break;
                case '@':
                    squares.add(new Utility(s[0].substring(1), i, Integer.parseInt(s[1]),
                            Integer.parseInt(s[2]), s[3]));
                    break;
            }
        }

        cards = new ArrayList<>();
        ChanceCard.Cards[] c = ChanceCard.Cards.values();

        for (int i = 0; i < NUMBER_OF_CARDS; i++) {
            for (int j = 0; j < c.length - 1; j++) {
                cards.add(new ChanceCard(c[j]));
            }
        }

        cards.add(new ChanceCard(ChanceCard.Cards.GET_OUT_OF_JAIL));
        cards.add(new ChanceCard(ChanceCard.Cards.GET_OUT_OF_JAIL));
        Collections.shuffle(cards);
    }

    /**
     * Draws and returns the next chance card from the deck.
     * GET_OUT_OF_JAIL cards are not returned to the deck; other cards are reshuffled back.
     *
     * @return the ChanceCard drawn.
     */
    public ChanceCard takeChanceCard() {
        ChanceCard card = cards.removeFirst();
        if (card.getType() != ChanceCard.Cards.GET_OUT_OF_JAIL) {
            cards.add(card);
        }
        return card;
    }

    /**
     * Retrieves the square at the specified board position.
     *
     * @param position the index on the board (0-based).
     * @return the Square located at the specified position.
     */
    public Square getSquare(int position) {
        return squares.get(position);
    }
}
