package am.monopoly.core;

/**
 * Represents a utility square on the Monopoly board, such as water works or electric company.
 * Utilities can be purchased and charge rent when other players land on them.
 */
public class Utility extends Square {

    /** The rent amount that must be paid when a player lands on this utility. */
    private int rent;

    /** The purchase price of the utility. */
    private int price;

    /**
     * Constructs a Utility with the specified name, position, rent, price, and color.
     *
     * @param name the name of the utility.
     * @param position the position on the board.
     * @param rent the rent amount charged to other players.
     * @param price the cost to purchase the utility.
     * @param color the color group or display color.
     */
    public Utility(String name, int position, int rent, int price, String color) {
        super(name, position, color);
        this.rent = rent;
        this.price = price;
    }

    /**
     * Returns the rent value of the utility.
     *
     * @return the rent amount.
     */
    public int getRent() {
        return rent;
    }

    /**
     * Returns the purchase price of the utility.
     *
     * @return the price.
     */
    public int getPrice() {
        return price;
    }
}
