package am.monopoly.core;

/**
 * Represents a property square on the Monopoly board.
 * Properties can have houses or hotels built on them, increasing rent.
 */
public class Property extends Square implements Constructible {

    /** The purchase price of the property. */
    private int price;

    /** The current rent value of the property. */
    private int rent;

    /**
     * Enum representing the construction status of a property.
     */
    public enum Status { HOUSE, HOTEL }

    /** The construction status of the property (HOUSE or HOTEL). */
    private Status status;

    /** The number of constructions (houses/hotel) built on this property. */
    private int numberOfStatus = 0;

    /**
     * Constructs a Property with a given name, position, price, rent, and color.
     *
     * @param name the name of the property.
     * @param position the position on the board.
     * @param price the purchase cost of the property.
     * @param rent the base rent value.
     * @param color the color group of the property.
     */
    public Property(String name, int position, int price, int rent, String color) {
        super(name, position, color);
        this.price = price;
        this.rent = rent;
    }

    /**
     * Builds a house on the property, increasing the rent.
     * Changes status to HOUSE if not already a HOTEL.
     */
    @Override
    public void buildHouse() {
        status = Status.HOUSE;
        if (numberOfStatus <= 4) {
            numberOfStatus++;
            rent = rent * numberOfStatus * 2;
        }
    }

    /**
     * Returns the current rent of the property.
     *
     * @return the rent amount.
     */
    public int getRent() {
        return rent;
    }

    /**
     * Sets a new rent value for the property.
     *
     * @param rent the new rent value.
     */
    public void setRent(int rent) {
        this.rent = rent;
    }

    /**
     * Returns the construction status of the property.
     *
     * @return the status (HOUSE or HOTEL).
     */
    @Override
    public Status getStatus() {
        return status;
    }

    /**
     * Sets the construction status of the property.
     *
     * @param status the new status to be set.
     */
    @Override
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * Returns the number of constructions on the property.
     *
     * @return the number of houses/hotel.
     */
    @Override
    public int getNumberOfStatus() {
        return numberOfStatus;
    }

    /**
     * Sets the number of constructions on the property.
     *
     * @param numberOfStatus the number of constructions.
     */
    @Override
    public void setNumberOfStatus(int numberOfStatus) {
        this.numberOfStatus = numberOfStatus;
    }

    /**
     * Returns the purchase price of the property.
     *
     * @return the price.
     */
    public int getPrice() {
        return price;
    }

    /**
     * Calculates and returns the current rent of the property.
     *
     * @return the calculated rent.
     */
    public int calculateRent() {
        return rent;
    }
}
